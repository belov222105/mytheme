=== Plugin Name ===
Contributors: unitecms
Donate link: http://addon-library.com/
Tags: addons,addon library,visual composer, visual composer addons, wpbakery, page builder
Requires at least: 3.5
Tested up to: 4.9.1
Stable tag: 1.2.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The biggest addon bundle for WPBakery Page Builder (Visual Composer) with +700 addons and +30 Predefined Templates. All addons are totally unique, crafted individually to fit your WPBakery Page Builder (Visual Composer) website.

== Description ==

Unlimited Addons is an endless suite of Addons for WPBakery Page Builder that lets you design & develop WPBakery pages with endless possibilities. 
Managing Addons is now easy fast & fun. 
We set out to create a unique directory of addons that you can install, configure, and use in a breeze. 
It doesnt matter if you are a beginner or an advanced WPbakery Page Builder user this add-on pack is the best tool you can find to extend WPBakery Page Builder to it's limits. 

Whats Included?

Simple Sliders (20)
Banners (24)
Pricing Tables (21)
Content Tabs (22)
Testimonials & Reviews (23)
Carousels (21)
Content Boxes (43)
Team Members (26)
Website Headers (20)
iHover Effects (20)
Icon Hover Effects (9)
Link Hover Effects (21)
Buttons (11)
Content Accordions (23)
Timer Countdowns (23)
Content Tabs (22)
Food Menus (24)
Social Network Icons (21)
Product Boxes (26)
Google Charts (7)
Video Teaser Popups (20)
Widgets (10)
Flip Boxes (15)
Video Galleries (7)
Opening Hours (15)
Mp3 Audio Players (15)
Statistic Counters (23)
Bullet Lists (25)
Footers (20)


> #### **View Our Website Demos**
>
> * <a href="http://unlimited-addons.com" target="_blank">Unlimited Addons for WPBakery Page Builder</a>


== Installation ==

1. Download the plugin then upload 'unlimited-addons' folder to the '/wp-content/plugins/'  directory
   --OR--
   Download and install the plugin 
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Download free addons or buy premium addons from us.
4. Import the addons pack zip and start using it in your favorite page builder

== Changelog ==

version 1.0:

plugin first release


== Frequently Asked Questions ==
There is no FAQ yet.

<?php

defined('UNLIMITED_ADDONS_INC') or die;

class UniteCreatorLayoutsViewProvider extends UniteCreatorLayoutsView{

	
}
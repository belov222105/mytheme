<?php

defined('UNLIMITED_ADDONS_INC') or die('Restricted access');

class GlobalsProviderUC{
	
	public static $pluginName;
	
	const VIEW_ADDONS_VC = "addons_vc";
   	const VIEW_ADDONS_ELEMENTOR = "addons_elementor";
	
   	const ADDONSTYPE_VC = "vc";
   	const ADDONSTYPE_ELEMENTOR = "elementor";
	
	const LAYOUTS_POST_TYPE = "uc_layout";
	
}
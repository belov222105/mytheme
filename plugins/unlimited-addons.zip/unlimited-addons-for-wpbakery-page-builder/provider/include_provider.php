<?php 
	$pathProvider = dirname(__FILE__)."/";
	
	require_once $pathProvider . 'provider_globals.class.php';
	require_once $pathProvider . 'provider_db.class.php';
	require_once $pathProvider . 'functions_wordpress.class.php';
	require_once $pathProvider . 'provider_functions.class.php';
	require_once $pathProvider . 'provider_helper.class.php';
	
	
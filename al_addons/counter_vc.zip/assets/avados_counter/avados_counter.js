

(function($) { 
"use strict"; 

$(window).on('load', function(){

$('.count, .counter_vc_addon').counterUp({
    delay: 10, // the delay time in ms
    time: 2000 // the speed time in ms
});

});

})(jQuery);
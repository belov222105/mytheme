(function($) { 
"use strict"; 


$(window).on('load', function(){



$('.how-we-work').owlCarousel({
  dots: true,
    loop:true,
    margin:30,
    nav:false,
	
responsiveClass:true,
    responsive:{
        0:{
            items:1
           
        },
        767:{
            items:3
       
        },
        1025:{
            items:4
           
        }
    }
});


});

})(jQuery);
(function($) { 
"use strict"; 

$(window).on('load', function(){




$('.avados_service_1_sl').owlCarousel({
    loop:true,
    margin:0,
dots:false,
    nav:true,
navText:false,
items:1,
     navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"]


})




});

})(jQuery);



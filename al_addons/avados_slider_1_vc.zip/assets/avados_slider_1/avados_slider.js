(function($) { 
"use strict"; 

$(window).on('load', function(){

$('.avados_slider_1').owlCarousel({

navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>'],
 margin:100,
 items:1,
	stagePadding: 440,
    loop:true,  
	dots: true,
    nav:true,
	responsiveClass:true,
    responsive:{
        0:{
		stagePadding: 50,
		  nav:false,
            items:1,
			dots: true,
        },
         320:{
	stagePadding: 50,
		 margin:20,
		  nav:false,
            items:1,
				dots: true,
        },
        370:{
	stagePadding: 50,
		 margin:20,
		  nav:false,
            items:1,
				dots: true,
        },
        1025:{
		stagePadding: 150,
		 margin:20,
		  nav:false,
            items:1,
				dots: true,
        },
        1170:{
         margin:100,
         items:1,
	stagePadding: 440,
        },
       
    }
})
 
    
});

})(jQuery);

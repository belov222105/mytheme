(function($) { 
"use strict"; 


$(window).on('load', function(){


$('.avados_slider_2_active').owlCarousel({
    loop:true,
    margin:20,
    nav:true,
navText: ['<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>'],
responsiveClass:true,
    responsive:{
        0:{
            items:1,
           	dots: true
        },
        768:{
            items:3
       
        },
        1025:{
            items:4
       
        }
    }

})

});

})(jQuery);
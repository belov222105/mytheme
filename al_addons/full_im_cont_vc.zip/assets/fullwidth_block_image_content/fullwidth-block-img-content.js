(function($) { 
"use strict"; 

$(window).on('load', function(){




$('.active-slider-fullwidth-block-slider').owlCarousel({
    loop:true,
    margin:0,
dots:true,
    nav:true,
navText:false,
items:1,
     navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"]


})




});

})(jQuery);



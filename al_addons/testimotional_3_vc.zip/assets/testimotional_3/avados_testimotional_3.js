(function($) { 
"use strict"; 


$(window).on('load', function(){


$('.testimotiona_3').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
navText:false,
items:1

})

});

})(jQuery);